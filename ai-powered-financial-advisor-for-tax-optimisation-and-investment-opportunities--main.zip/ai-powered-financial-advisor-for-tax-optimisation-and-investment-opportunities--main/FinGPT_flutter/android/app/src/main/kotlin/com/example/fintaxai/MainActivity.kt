package com.example.fintaxai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
